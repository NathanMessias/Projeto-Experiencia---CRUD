from django.db import models

# Create your models here.
class empresa(models.Model):

    nomeEmp = models.CharField(
        max_length=255,
        null= False,
        blank= False
    )

    cnpj = models.CharField(
        max_length= 11,
        null=False,
        blank=False
    )

    nomeResp = models.CharField(
        max_length=255,
        null = False,
        blank = False
    )

    endereco = models.CharField(
        max_length=255,
        null = False,
        blank = False
    )

    cidade = models.CharField(
        max_length=45,
        null = False,
        blank = False
    )

    estado= models.CharField(
        max_length=45,
        null = False,
        blank = False
    )

    foneEmp= models.CharField(
        max_length=8,
        null = False,
        blank = False
    )

    foneResp= models.CharField(
        max_length=11,
        null = False,
        blank = False
    )

    dataNasc = models.DateField(
        null=False,
        blank=False
    )


    objetos = models.Manager()