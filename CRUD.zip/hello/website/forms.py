from django import forms
from hello.models import empresa

class InsereEmpresaForm(forms.ModelForm):
    class Meta:
        #Modelo Base
        model = empresa

        fields = [
            'nomeEmp',
            'cnpj',
            'nomeResp',
            'endereco',
            'cidade',
            'estado',
            'foneEmp',
            'foneResp',
            'dataNasc'
        ]
