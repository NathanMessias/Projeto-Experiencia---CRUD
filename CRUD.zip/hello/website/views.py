from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import TemplateView, ListView, UpdateView, CreateView, DeleteView
from hello.models import empresa
from website.forms import InsereEmpresaForm

# Create your views here.

class IndexTemplateView(TemplateView):
    template_name="website/index.html"

class EmpresaListView(ListView):
    template_name="website/lista.html"
    model= empresa
    context_object_name="empresa"

class EmpresaUpdateView(UpdateView):
    template_name = 'website/atualiza.html'
    model = empresa
    fields = '__all__'
    context_object_name = 'empresa'
    success_url = reverse_lazy("website:lista_empresa")

class EmpresaDeleteView(DeleteView):
    template_name="website/exclui.html"
    model = empresa
    context_object_name='empresa'
    success_url=reverse_lazy(
        "website:lista_empresa" )


class EmpresaCreateView(CreateView):
    template_name = "website/cria.html"
    model = empresa
    form_class = InsereEmpresaForm
    success_url = reverse_lazy("website:lista_empresa")