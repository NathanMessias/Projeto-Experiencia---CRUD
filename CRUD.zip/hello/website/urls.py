from website.views import IndexTemplateView, EmpresaListView, EmpresaUpdateView, \
    EmpresaDeleteView, EmpresaCreateView


from django.urls import path

app_name = 'website'

urlpatterns = [
    # GET /
    path('', IndexTemplateView.as_view(), name="index"),

    # GET /empresa/cadastrar
    path('empresa/cadastrar', EmpresaCreateView.as_view(), name="cadastra_empresa"),

    # GET /empresa
    path('empresa/', EmpresaListView.as_view(), name="lista_empresa"),

    # GET/POST /empresa/{pk}
    path('empresa/<pk>', EmpresaUpdateView.as_view(), name="atualiza_empresa"),

    # GET/POST /empresa/excluir/{pk}
    path('empresa/excluir/<pk>', EmpresaDeleteView.as_view(), name="deleta_empresa"),


]